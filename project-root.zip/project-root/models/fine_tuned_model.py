from transformers import AutoModelForSeq2SeqLM, AutoTokenizer, Trainer, TrainingArguments
from datasets import load_dataset, Dataset
import torch

# Load dataset
# Assuming the dataset is in a CSV format with columns: ['Report Name', 'History', 'Observation', 'Impressions']
dataset = load_dataset('csv', data_files={'train': 'train.csv', 'eval': 'eval.csv'})

# Preprocessing and tokenization
model_name = "gemma-2b-it"  # or "gemma-7b-it" based on your hardware
tokenizer = AutoTokenizer.from_pretrained(model_name)

def preprocess_function(examples):
    inputs = examples['Report Name'] + ' ' + examples['History'] + ' ' + examples['Observation']
    targets = examples['Impressions']
    model_inputs = tokenizer(inputs, max_length=512, truncation=True, padding="max_length")
    labels = tokenizer(targets, max_length=512, truncation=True, padding="max_length").input_ids
    model_inputs["labels"] = labels
    return model_inputs

tokenized_datasets = dataset.map(preprocess_function, batched=True)

# Load pre-trained model
model = AutoModelForSeq2SeqLM.from_pretrained(model_name)

# Training arguments
training_args = TrainingArguments(
    output_dir="./results",
    evaluation_strategy="epoch",
    learning_rate=2e-5,
    per_device_train_batch_size=4,
    per_device_eval_batch_size=4,
    num_train_epochs=3,
    weight_decay=0.01,
)

# Initialize Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_datasets["train"],
    eval_dataset=tokenized_datasets["eval"],
)

# Train the model
trainer.train()

# Save the model
trainer.save_model("./fine_tuned_model")
